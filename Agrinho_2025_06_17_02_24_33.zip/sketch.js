// --- Variáveis Globais e Constantes ---

// Estados do jogo
let gameState = "startScreen"; // 'startScreen', 'playing', 'shop'

// Dinheiro
let money = 0;

// Mensagens de status
let statusMensagem = "Bem-vindo ao Campo & Cidade!";

// Cores base
const CORES = {
  BROTO_GENERICO: [100, 180, 50],
  CAULE: [139, 69, 19],
  FOLHA_PADRAO: [0, 128, 0],
  TERRA_PLANTIO: [100, 50, 0], // Mantido para consistência, mas não será a área de plantio
  CÉU_INICIO: [173, 216, 230],
  CÉU_JOGO_TOPO: [135, 206, 235],
  CÉU_JOGO_BASE: [173, 216, 230],
  GRAMA_FUNDO: [80, 150, 50],
  GRAMA_MEIO: [130, 200, 80],
  GRAMA_FRENTE: [170, 220, 120]
};

// Configurações da animação da tela inicial (reintroduzido)
const START_PLANT = {
  SCALE: 1,
  SCALE_DIRECTION: 0.005
};

// Tipos de sementes (tempo em segundos) - PREÇOS AUMENTADOS
const tiposSemente = [
  { id: "carrot", nome: "Cenoura", corSemente: [255, 140, 0], tempoCrescimento: 5, valorVenda: 30, precoCompra: 0, design: "carrot", desbloqueado: true }, // Valor de venda ajustado
  { id: "tomato", nome: "Tomate", corSemente: [220, 20, 60], tempoCrescimento: 7, valorVenda: 80, precoCompra: 160, design: "tomato", desbloqueado: false }, // Valor e preço ajustados
  { id: "wheat", nome: "Trigo", corSemente: [218, 165, 32], tempoCrescimento: 4, valorVenda: 40, precoCompra: 80, design: "wheat", desbloqueado: false }, // Valor e preço ajustados
  { id: "corn", nome: "Milho", corSemente: [255, 255, 0], tempoCrescimento: 6, valorVenda: 90, precoCompra: 180, design: "corn", desbloqueado: false }, // Valor e preço ajustados
  { id: "strawberry", nome: "Morango", corSemente: [255, 0, 0], tempoCrescimento: 8, valorVenda: 150, precoCompra: 250, design: "strawberry", desbloqueado: false }, // Valor e preço ajustados
  { id: "lettuce", nome: "Alface", corSemente: [100, 180, 50], tempoCrescimento: 4.5, valorVenda: 60, precoCompra: 120, design: "lettuce", desbloqueado: false } // Valor e preço ajustados
];
let sementeSelecionada = 0; // Índice da semente selecionada

// Itens da Loja - PREÇOS AUMENTADOS
const lojaItens = [
  { id: "adubo", nome: "Adubo Natural", preco: 250, descricao: "Acelera o crescimento por 5s.", tipo: "ferramenta" }, // Preço ajustado
  { id: "arvore", nome: "Muda de Árvore", preco: 400, descricao: "Gera frutos valiosos.", tipo: "ferramenta" }, // Preço ajustado
  { id: "regador", nome: "Regador Automático", preco: 300, descricao: "Regador automático p/ todas plantas.", tipo: "ferramenta" } // Preço ajustado
];

// Estados de itens comprados
let aduboAtivo = false;
let aduboTempoRestante = 0; // Em frames
let temRegador = false; // Estado do regador automático

// Plantas e árvores no campo
let plantas = [];
let arvoresPlantadas = [];
const ARVORE_FRUIT_INTERVAL_SECONDS = 10;
const ARVORE_FRUIT_VALUE = 10; // Valor de venda do fruto da árvore

// Alertas de colheita
const GROW_ALERT_DURATION = 120; // 2 segundos (120 frames)
let growAlerts = []; // [{plantIndex: N, timer: M}]

// Configurações da Loja (janela e scroll)
const SHOP = {
  WINDOW_X: 100,
  WINDOW_Y: 100,
  WINDOW_WIDTH: 700,
  WINDOW_HEIGHT: 300,
  SCROLL_Y: 0,
  CONTENT_HEIGHT: 0
};

// --- Funções de Setup e Loop Principal ---

function setup() {
  createCanvas(900, 550);
  textSize(18);
  textAlign(CENTER, CENTER);
  money = 150; // Dinheiro inicial
  frameRate(60); // Garante 60 frames por segundo para consistência de tempo

  // Calcular a altura total do conteúdo da loja para o scroll
  SHOP.CONTENT_HEIGHT = 40 + (lojaItens.length * 80) + 40 + 40 + (tiposSemente.filter(s => s.precoCompra > 0).length * 80);
  SHOP.CONTENT_HEIGHT = max(SHOP.CONTENT_HEIGHT, SHOP.WINDOW_HEIGHT); // Garante que o conteúdo mínimo é a altura da janela
}

function draw() {
  background(220);

  switch (gameState) {
    case "startScreen":
      drawStartScreen();
      break;
    case "playing":
      drawGame();
      break;
    case "shop":
      drawShop();
      break;
  }
}

// --- Funções da Tela Inicial ---

function drawStartScreen() {
  background(CORES.CÉU_INICIO); // Céu azul claro
  drawStartScreenGround();

  // Animação da planta principal (reintroduzido)
  push();
  translate(width / 2, height * 0.7 - 20);
  scale(START_PLANT.SCALE);
  drawGenericAnimatedPlant();
  pop();

  START_PLANT.SCALE += START_PLANT.SCALE_DIRECTION;
  if (START_PLANT.SCALE > 1.05 || START_PLANT.SCALE < 0.95) {
    START_PLANT.SCALE_DIRECTION *= -1;
  }

  // Texto do título
  fill(255);
  textSize(50);
  text("Campo & Cidade:", width / 2, height / 2 - 100);
  textSize(40);
  text("A Colheita!", width / 2, height / 2 - 40);

  drawStartButton();
}

function drawStartScreenGround() {
  fill(CORES.GRAMA_FRENTE); // Cor de grama principal
  rect(0, height * 0.7, width, height * 0.3); // Área de grama mais próxima
  fill(CORES.TERRA_PLANTIO); // Terra marrom simples para simular "terra" na tela inicial
  rect(0, height * 0.85, width, height * 0.15);
  noStroke();
}

function drawGenericAnimatedPlant() { // Reintroduzido
  let baseSize = 100;
  fill(CORES.CAULE);
  rectMode(CENTER);
  rect(0, baseSize * 0.2, baseSize / 5, baseSize * 0.8);
  rectMode(CORNER);
  fill(CORES.FOLHA_PADRAO);
  ellipse(0, -baseSize * 0.3, baseSize * 0.8, baseSize * 0.8);
  ellipse(-baseSize * 0.25, 0, baseSize * 0.5, baseSize * 0.5);
  ellipse(baseSize * 0.25, 0, baseSize * 0.5, baseSize * 0.5);
  fill(255, 165, 0); // Cor da flor genérica
  ellipse(0, -baseSize * 0.55, baseSize * 0.4, baseSize * 0.4);
}


function drawStartButton() {
  fill(0, 150, 0);
  rectMode(CENTER);
  rect(width / 2, height / 2 + 50, 200, 60, 10);
  fill(255);
  textSize(28);
  text("JOGAR", width / 2, height / 2 + 50);
  rectMode(CORNER);
}

// --- Funções do Jogo Principal ---

function drawGame() {
  drawBackgroundScenario();
  displayHUD();
  updateAndDrawPlants();
  updateAndDrawTrees();
  updateAduboStatus();
  drawSeedSelector();
  drawShopBuilding();
}

function displayHUD() {
  fill(0);
  textSize(18);
  textAlign(CENTER, TOP);
  text(statusMensagem, width / 2, 10);

  textAlign(RIGHT, TOP);
  textSize(22);
  fill(50, 50, 50);
  text("Dinheiro: $" + money, width - 20, 10);
  textAlign(CENTER, CENTER);
}

function updateAndDrawPlants() {
  for (let i = plantas.length - 1; i >= 0; i--) { // Iterar de trás para frente para splice
    let planta = plantas[i];

    if (!planta.cresceu) {
      drawGrowingPlant(planta);
      updatePlantGrowth(planta);
      checkPlantGrowthCompletion(planta, i);
    } else {
      drawPlant(planta.x, planta.y, 50, planta.tipo.design);
    }
  }
  manageGrowAlerts();
}

function drawGrowingPlant(planta) {
  if (planta.tamanhoAtual < 30) {
    drawSeedVisual(planta.x, planta.y, planta.tamanhoAtual, planta.tipo.corSemente);
  } else {
    drawBrotoVisual(planta.x, planta.y, planta.tamanhoAtual);
  }
}

function updatePlantGrowth(planta) {
  planta.tempoCrescimentoRestante--;

  let growthSpeed = 1;
  if (aduboAtivo) growthSpeed = 2;
  if (planta.regada) growthSpeed *= 1.5;
  if (temRegador) growthSpeed *= 1.2;

  if (planta.tamanhoAtual < 50) {
    planta.tamanhoAtual += (50 - 15) / (planta.tempoTotalCrescimento / 2) * growthSpeed;
  }
  // Reseta o estado de regada manual para o próximo frame
  if (planta.regada && !temRegador) {
    planta.regada = false;
  }
}

function checkPlantGrowthCompletion(planta, index) {
  if (!planta.cresceu && planta.tempoCrescimentoRestante <= 0) {
    planta.cresceu = true;
    statusMensagem = `A ${planta.tipo.nome} cresceu! Clique para colher.`;
    planta.tamanhoAtual = 50;
    growAlerts.push({ plantIndex: index, timer: GROW_ALERT_DURATION });
  }
}

function manageGrowAlerts() {
  for (let i = growAlerts.length - 1; i >= 0; i--) {
    let alert = growAlerts[i];
    alert.timer--;
    let planta = plantas[alert.plantIndex]; // Obter a planta pelo índice

    if (alert.timer <= 0 || !planta || !planta.cresceu) {
      growAlerts.splice(i, 1); // Remove se o tempo acaba ou a planta não existe/foi colhida
    } else {
      // Desenha o feedback visual
      fill(255, 255, 0, map(alert.timer, 0, GROW_ALERT_DURATION, 0, 150));
      ellipse(planta.x, planta.y - 40, 30, 30);
      fill(0, map(alert.timer, 0, GROW_ALERT_DURATION, 0, 255));
      textSize(16);
      text("!", planta.x, planta.y - 40);
    }
  }
}

function updateAndDrawTrees() {
  for (let arvore of arvoresPlantadas) {
    drawTree(arvore.x, arvore.y);
    if (arvore.frutoPronto) {
      fill(255, 100, 0); // Fruto laranja
      ellipse(arvore.x + 20, arvore.y - 70, 20, 20);
      fill(0);
      textSize(14);
      text("$", arvore.x + 20, arvore.y - 70);
    }
    arvore.fruitTimer++;
    if (arvore.fruitTimer >= ARVORE_FRUIT_INTERVAL_SECONDS * 60) {
      arvore.frutoPronto = true;
      arvore.fruitTimer = 0;
    }
  }
}

function updateAduboStatus() {
  if (aduboAtivo) {
    aduboTempoRestante--;
    if (aduboTempoRestante <= 0) {
      aduboAtivo = false;
      statusMensagem = "O efeito do adubo natural acabou.";
    } else {
      statusMensagem = `Adubo ativo! Tempo restante: ${ceil(aduboTempoRestante / 60)}s`;
    }
  }
}

function drawShopBuilding() {
  fill(0, 100, 200);
  rect(width - 120, height - 200, 100, 140, 10);
  fill(255, 255, 0);
  rect(width - 110, height - 200, 80, 30, 5);
  fill(0);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("LOJA", width - 70, height - 185);
  fill(50);
  rect(width - 70, height - 120, 20, 40);
}

// --- Funções de Desenho Específicas de Plantas ---

function drawSeedVisual(x, y, size, corSemente) {
  fill(corSemente);
  noStroke();
  ellipse(x, y, size * 0.4, size * 0.4);
  fill(CORES.CAULE); // Pequena terra ao redor
  ellipse(x, y + 5, size * 0.6, size * 0.2);
}

function drawBrotoVisual(x, y, size) {
  fill(CORES.BROTO_GENERICO);
  noStroke();
  rect(x - 2, y + 10, 4, -size / 2); // haste vertical
  ellipse(x - 5, y + 5 - size / 2, 10, 8);
  ellipse(x + 5, y + 5 - size / 2, 10, 8);
}

function drawPlant(x, y, size, designType) {
  noStroke();
  push();
  translate(x, y);

  fill(CORES.CAULE);
  rectMode(CENTER);
  rect(0, size * 0.1, size / 8, size * 0.7);
  rectMode(CORNER);

  switch (designType) {
    case "carrot":
      fill(255, 140, 0);
      triangle(-size * 0.15, -size * 0.2, size * 0.15, -size * 0.2, 0, -size * 0.7);
      fill(CORES.FOLHA_PADRAO);
      rect(-size * 0.1, -size * 0.7, size * 0.05, size * 0.2);
      rect(size * 0.05, -size * 0.7, size * 0.05, size * 0.2);
      rect(-size * 0.02, -size * 0.6, size * 0.05, size * 0.15);
      break;
    case "tomato":
      fill(CORES.FOLHA_PADRAO);
      ellipse(0, -size * 0.2, size * 0.7, size * 0.4);
      ellipse(-size * 0.2, -size * 0.1, size * 0.3, size * 0.2);
      ellipse(size * 0.2, -size * 0.1, size * 0.3, size * 0.2);
      fill(220, 20, 60);
      ellipse(0, -size * 0.4, size * 0.3, size * 0.3);
      ellipse(-size * 0.18, -size * 0.3, size * 0.2, size * 0.2);
      ellipse(size * 0.18, -size * 0.3, size * 0.2, size * 0.2);
      break;
    case "wheat":
      fill(218, 165, 32);
      rectMode(CENTER);
      rect(0, -size * 0.3, size * 0.2, size * 0.6);
      rect(-size * 0.1, -size * 0.1, size * 0.1, size * 0.3);
      rect(size * 0.1, -size * 0.1, size * 0.1, size * 0.3);
      rectMode(CORNER);
      break;
    case "corn":
      fill(CORES.CAULE);
      rectMode(CENTER);
      rect(0, -size * 0.1, size * 0.15, size * 0.8);
      rectMode(CORNER);
      fill(CORES.FOLHA_PADRAO);
      triangle(-size * 0.1, -size * 0.2, size * 0.2, -size * 0.1, 0, size * 0.1);
      triangle(size * 0.1, -size * 0.2, -size * 0.2, -size * 0.1, 0, size * 0.1);
      fill(255, 255, 0);
      ellipse(-size * 0.15, -size * 0.3, size * 0.25, size * 0.5);
      ellipse(size * 0.15, -size * 0.1, size * 0.25, size * 0.5);
      break;
    case "strawberry":
      fill(CORES.FOLHA_PADRAO);
      ellipse(0, size * 0.1, size * 0.6, size * 0.3);
      triangle(-size * 0.2, 0, size * 0.2, 0, 0, -size * 0.3);
      fill(255, 0, 0);
      triangle(-size * 0.15, -size * 0.35, size * 0.15, -size * 0.35, 0, -size * 0.6);
      fill(255, 255, 0, 150);
      ellipse(-size * 0.05, -size * 0.45, 2, 2);
      ellipse(size * 0.05, -size * 0.45, 2, 2);
      ellipse(0, -size * 0.5, 2, 2);
      fill(CORES.FOLHA_PADRAO);
      ellipse(0, -size * 0.6, 10, 10);
      break;
    case "lettuce":
      fill(144, 238, 144);
      ellipse(0, -size * 0.3, size * 0.8, size * 0.6);
      fill(124, 200, 124);
      ellipse(0, -size * 0.35, size * 0.6, size * 0.5);
      fill(100, 160, 100);
      ellipse(0, -size * 0.4, size * 0.4, size * 0.3);
      break;
  }
  pop();
}

function drawTree(x, y) {
  fill(CORES.CAULE);
  rect(x, y - 50, 20, 60);
  fill(34, 139, 34);
  ellipse(x + 10, y - 80, 70, 70);
  ellipse(x - 10, y - 60, 50, 50);
  ellipse(x + 30, y - 60, 50, 50);
}

// --- Funções de Cenário ---

function drawBackgroundScenario() {
  drawSky();
  drawClouds();
  drawFieldLayers(); // Agora a plantação será em todas as camadas de grama
  drawRoad(); // A estrada simplificada
  drawCityscape();
}

function drawSky() {
  for (let i = 0; i < height * 0.6; i++) {
    let inter = map(i, 0, height * 0.6, 0, 1);
    let c = lerpColor(color(CORES.CÉU_JOGO_TOPO), color(CORES.CÉU_JOGO_BASE), inter);
    stroke(c);
    line(0, i, width, i);
  }
  noStroke();
  fill(255, 255, 0, 200); // Sol
  ellipse(width * 0.1, height * 0.15, 100, 100);
}

function drawClouds() {
  fill(255, 255, 255, 200);
  ellipse(width * 0.3, height * 0.1, 70, 50);
  ellipse(width * 0.35, height * 0.12, 80, 60);
  ellipse(width * 0.25, height * 0.15, 60, 40);
  ellipse(width * 0.6, height * 0.08, 90, 70);
  ellipse(width * 0.65, height * 0.1, 80, 60);
  ellipse(width * 0.55, height * 0.12, 70, 50);
}

function drawFieldLayers() {
  // Agora as camadas de grama cobrem a maior parte do campo
  fill(CORES.GRAMA_FUNDO); // Camada de grama mais ao fundo
  rect(0, height * 0.2, width, height * 0.8);
  noStroke();
  fill(CORES.GRAMA_MEIO); // Camada do meio
  rect(0, height * 0.35, width, height * 0.65);
  fill(CORES.GRAMA_FRENTE); // Camada mais à frente (onde o plantio acontecerá)
  rect(0, height * 0.5, width * 0.7, height * 0.5); // Apenas até a estrada
}

function drawRoad() {
  fill(70, 70, 70);
  // Revertendo para o quad original, mas com coordenadas ajustadas
  quad(width * 0.65, height * 0.7, // Top-left point
       width * 0.7, height * 0.7,  // Top-right point
       width * 0.75, height,       // Bottom-right point
       0, height);                 // Bottom-left point
  stroke(255, 255, 0);
  strokeWeight(3);
  for (let i = 0.1; i < 0.9; i += 0.1) {
    line(lerp(width * 0.65, width * 0.75, i), lerp(height * 0.7, height, i),
         lerp(width * 0.65, width * 0.75, i + 0.05), lerp(height * 0.7, height, i + 0.05));
  }
  noStroke();
}


function drawCityscape() {
  fill(180, 180, 180);
  rect(width * 0.7 + 10, 0, width * 0.3 - 10, height);

  // Prédios
  drawBuilding(width * 0.73, height - 180, 70, 170, [100, 100, 150], [200, 200, 255], "triangle");
  drawBuilding(width * 0.82, height - 120, 50, 110, [150, 120, 100], [250, 250, 150]);
  drawBuilding(width * 0.90, height - 250, 70, 240, [90, 160, 90], [200, 200, 255]);

  drawLightPosts();
}

// Função auxiliar para desenhar prédios de forma mais genérica
function drawBuilding(x, y, w, h, bodyColor, windowColor, roofType = null) {
  fill(bodyColor);
  rect(x, y, w, h);
  fill(windowColor);
  // Janelas (simplificado, pode ser mais complexo)
  rect(x + w * 0.1, y + h * 0.1, w * 0.2, h * 0.15);
  rect(x + w * 0.5, y + h * 0.1, w * 0.2, h * 0.15);
  rect(x + w * 0.1, y + h * 0.3, w * 0.2, h * 0.15);
  rect(x + w * 0.5, y + h * 0.3, w * 0.2, h * 0.15);

  if (roofType === "triangle") {
    fill(150, 150, 150);
    triangle(x, y, x + w, y, x + w / 2, y - 20);
  }
}

function drawLightPosts() {
  fill(50);
  rect(width * 0.78, height - 80, 5, 60);
  ellipse(width * 0.78 + 2.5, height - 80, 15, 15);
  rect(width * 0.71, height - 100, 5, 80);
  ellipse(width * 0.71 + 2.5, height - 100, 15, 15);
}

// --- Funções da Loja ---

function drawShop() {
  background(200, 220, 255);
  displayShopHeader();
  drawShopWindow();
  drawShopContent();
  drawShopScrollbar();
  drawShopBackButton();
}

function displayShopHeader() {
  fill(0);
  textSize(30);
  text("LOJA DA CIDADE", width / 2, 50);
  textSize(22);
  textAlign(RIGHT, TOP);
  fill(50, 50, 50);
  text("Dinheiro: $" + money, width - 20, 20);
  textAlign(CENTER, CENTER);
}

function drawShopWindow() {
  fill(240);
  stroke(150);
  rect(SHOP.WINDOW_X, SHOP.WINDOW_Y, SHOP.WINDOW_WIDTH, SHOP.WINDOW_HEIGHT, 10);
  noStroke();
}

function drawShopContent() {
  push();
  translate(SHOP.WINDOW_X, SHOP.WINDOW_Y + SHOP.SCROLL_Y);

  let currentY = 20;

  currentY = drawShopSection("Itens Especiais:", lojaItens, currentY, drawShopItem);
  currentY = drawShopSection("Comprar Sementes:", tiposSemente.filter(s => s.precoCompra > 0), currentY, drawShopSeed);

  pop();
}

function drawShopSection(title, items, startY, drawFunction) {
  fill(0);
  textSize(25);
  textAlign(LEFT, TOP);
  text(title, 10, startY);
  let y = startY + 40;

  for (let item of items) {
    drawFunction(item, y);
    y += 80;
  }
  return y;
}

function drawShopItem(item, y) {
  fill(255);
  stroke(0);
  rect(10, y, SHOP.WINDOW_WIDTH - 40, 60, 10);

  fill(0);
  textSize(20);
  textAlign(LEFT, CENTER);
  text(item.nome, 20, y + 20);
  textSize(14);
  text(item.descricao, 20, y + 45);

  let isDisabled = (item.id === "regador" && temRegador) || money < item.preco;
  drawBuyButton(item, y, isDisabled);
}

function drawShopSeed(semente, y) {
  fill(255);
  stroke(0);
  rect(10, y, SHOP.WINDOW_WIDTH - 40, 60, 10);

  fill(0);
  textSize(20);
  textAlign(LEFT, CENTER);
  text(semente.nome, 20, y + 20);
  textSize(14);
  text(`Valor de venda: $${semente.valorVenda} | Cresce em ${semente.tempoCrescimento}s`, 20, y + 45);

  let isDisabled = semente.desbloqueado || money < semente.precoCompra;
  drawBuyButton(semente, y, isDisabled, true); // Passa true para indicar que é uma semente
}

function drawBuyButton(item, y, isDisabled, isSeed = false) {
  let buttonColor = isDisabled ? [150, 150, 150] : [50, 200, 50];
  fill(buttonColor);

  let buyButtonX = 10 + (SHOP.WINDOW_WIDTH - 40) - 80;
  let buyButtonY = y + 15;
  rect(buyButtonX, buyButtonY, 70, 30, 5);

  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);

  if (isSeed) {
    text(item.desbloqueado ? "ADQUIRIDA" : `$${item.precoCompra}`, buyButtonX + 35, buyButtonY + 15);
  } else {
    text(item.id === "regador" && temRegador ? "ADQUIRIDO" : `$${item.preco}`, buyButtonX + 35, buyButtonY + 15);
  }
}

function drawShopScrollbar() {
  let scrollbarWidth = 10;
  let scrollbarX = SHOP.WINDOW_X + SHOP.WINDOW_WIDTH - scrollbarWidth - 5;
  let scrollbarTrackHeight = SHOP.WINDOW_HEIGHT - 20;
  let scrollbarTrackY = SHOP.WINDOW_Y + 10;

  fill(200);
  rect(scrollbarX, scrollbarTrackY, scrollbarWidth, scrollbarTrackHeight, 5);

  let scrollHandleHeight = map(SHOP.WINDOW_HEIGHT, 0, SHOP.CONTENT_HEIGHT, 0, scrollbarTrackHeight);
  scrollHandleHeight = constrain(scrollHandleHeight, 30, scrollbarTrackHeight);

  let handlePosNormalized = map(SHOP.SCROLL_Y, -(SHOP.CONTENT_HEIGHT - SHOP.WINDOW_HEIGHT), 0, 0, 1);
  let scrollHandleY = lerp(scrollbarTrackY + scrollbarTrackHeight - scrollHandleHeight, scrollbarTrackY, handlePosNormalized);
  scrollHandleY = constrain(scrollHandleY, scrollbarTrackY, scrollbarTrackY + scrollbarTrackHeight - scrollHandleHeight);

  fill(100);
  rect(scrollbarX, scrollHandleY, scrollbarWidth, scrollHandleHeight, 5);
}

function drawShopBackButton() {
  fill(200, 50, 50);
  rectMode(CENTER);
  rect(width / 2, height - 30, 120, 50, 10);
  fill(255);
  textSize(20);
  text("VOLTAR", width / 2, height - 30);
  rectMode(CORNER);
}

// --- Funções do Seletor de Sementes ---
function drawSeedSelector() {
  let selectorY = height - 50;
  // Ajusta o selector para a área do campo (width * 0.7)
  let selectorX = (width * 0.7) / 2;
  let buttonWidth = 100;
  let buttonHeight = 40;
  let spacing = 10;

  let visibleSeeds = tiposSemente.filter(s => s.desbloqueado);
  let totalWidth = visibleSeeds.length * (buttonWidth + spacing) - spacing; // Remove o último espaçamento
  let startDrawingX = selectorX - totalWidth / 2;

  for (let i = 0; i < visibleSeeds.length; i++) {
    let semente = visibleSeeds[i];
    let xPos = startDrawingX + i * (buttonWidth + spacing) + buttonWidth / 2;

    if (semente.id === tiposSemente[sementeSelecionada].id) {
      fill(100, 100, 255);
    } else {
      fill(150, 200, 255);
    }
    rectMode(CENTER); // Desenha o botão de semente com CENTER
    rect(xPos, selectorY, buttonWidth, buttonHeight, 5);

    fill(0);
    textSize(16);
    text(semente.nome, xPos, selectorY);
  }
  rectMode(CORNER); // Reseta para CORNER após desenhar todos os botões do seletor
}


// --- Funções de Interação ---

function mousePressed() {
  switch (gameState) {
    case "startScreen":
      handleStartScreenClick();
      break;
    case "playing":
      handlePlayingClick();
      break;
    case "shop":
      handleShopClick();
      break;
  }
}

function handleStartScreenClick() {
  let buttonX = width / 2;
  let buttonY = height / 2 + 50;
  let buttonWidth = 200;
  let buttonHeight = 60;

  if (dist(mouseX, mouseY, buttonX, buttonY) < buttonWidth / 2 && dist(mouseX, mouseY, buttonX, buttonY) < buttonHeight / 2) {
    gameState = "playing";
    statusMensagem = "Clique na grama para plantar uma semente!";
    money = 150;
    arvoresPlantadas = [];
    aduboAtivo = false;
    aduboTempoRestante = 0;
    temRegador = false;
    tiposSemente.forEach(s => s.desbloqueado = (s.id === "carrot"));
    plantas = [];
    growAlerts = [];
    sementeSelecionada = 0;
    SHOP.SCROLL_Y = 0;
  }
}

function handlePlayingClick() {
  // Clique na loja
  if (mouseX > width - 120 && mouseX < width - 20 && mouseY > height - 200 && mouseY < height - 60) {
    gameState = "shop";
    statusMensagem = "Bem-vindo à Loja da Cidade!";
    return;
  }

  // Seleção de sementes
  let selectorY = height - 50;
  let buttonWidth = 100;
  let buttonHeight = 40;
  let spacing = 10;
  let visibleSeeds = tiposSemente.filter(s => s.desbloqueado);
  let totalWidth = visibleSeeds.length * (buttonWidth + spacing) - spacing;
  let startDrawingX = (width * 0.7) / 2 - totalWidth / 2;

  for (let i = 0; i < visibleSeeds.length; i++) {
    let sementeNaBarra = visibleSeeds[i];
    let xPos = startDrawingX + i * (buttonWidth + spacing) + buttonWidth / 2;
    if (dist(mouseX, mouseY, xPos, selectorY) < buttonWidth / 2 && dist(mouseX, mouseY, xPos, selectorY) < buttonHeight / 2) {
      sementeSelecionada = tiposSemente.findIndex(s => s.id === sementeNaBarra.id);
      statusMensagem = `Semente de ${tiposSemente[sementeSelecionada].nome} selecionada. Clique na grama para plantar!`;
      return;
    }
  }

  // INTERAÇÃO COM A ÁREA DE PLANTIO (APENAS NAS ÁREAS VERDES)
  // Define a área onde o plantio é permitido
  const PLANTIO_X_MIN = 0;
  const PLANTIO_X_MAX = width * 0.7; // Até a estrada/cidade
  const PLANTIO_Y_MIN = height * 0.5; // Início da camada de grama mais próxima
  const PLANTIO_Y_MAX = height; // Até a base da tela (abaixo da estrada também é grama)


  if (mouseX >= PLANTIO_X_MIN && mouseX <= PLANTIO_X_MAX &&
      mouseY >= PLANTIO_Y_MIN && mouseY <= PLANTIO_Y_MAX) {
    if (!tryHarvestOrWaterPlant()) { // Tenta colher ou regar uma planta existente
      plantNewSeed(); // Se não interagiu com planta, tenta plantar
    }
    return;
  } else {
    // Mensagem para informar que só pode plantar na grama
    statusMensagem = "Você só pode plantar nas áreas verdes do campo!";
    return;
  }

  // Colher frutos das árvores
  tryHarvestTreeFruit();
}

function tryHarvestOrWaterPlant() {
  for (let i = 0; i < plantas.length; i++) {
    let planta = plantas[i];
    if (dist(mouseX, mouseY, planta.x, planta.y) < 30) { // Click radius
      if (planta.cresceu) {
        money += planta.tipo.valorVenda;
        statusMensagem = `Você colheu uma ${planta.tipo.nome} e ganhou $${planta.tipo.valorVenda}! Total: $${money}`;
        plantas.splice(i, 1);
        growAlerts = growAlerts.filter(alert => alert.plantIndex !== i);
      } else {
        if (!planta.regada && !temRegador) {
          planta.tempoCrescimentoRestante = max(0, planta.tempoCrescimentoRestante - (60 * 2));
          planta.regada = true;
          statusMensagem = `Você regou a ${planta.tipo.nome}! Ela crescerá mais rápido.`;
        } else if (temRegador) {
          statusMensagem = `Você tem um regador automático! As plantas são regadas sozinhas.`;
        } else {
          statusMensagem = `A ${planta.tipo.nome} já foi regada.`;
        }
      }
      return true; // Interagiu com uma planta
    }
  }
  return false; // Não interagiu com nenhuma planta
}

function plantNewSeed() {
  let tipoAtual = tiposSemente[sementeSelecionada];
  plantas.push({
    x: mouseX,
    y: mouseY,
    cresceu: false,
    tempoCrescimentoRestante: tipoAtual.tempoCrescimento * 60, // Tempo em frames
    tempoTotalCrescimento: tipoAtual.tempoCrescimento * 60, // Total em frames para cálculo de tamanho
    tamanhoAtual: 15,
    tipo: tipoAtual,
    regada: false
  });
  statusMensagem = `Plantei uma semente de ${tipoAtual.nome}! Aguarde ela crescer...`;
}

function tryHarvestTreeFruit() {
  for (let i = arvoresPlantadas.length - 1; i >= 0; i--) {
    let arvore = arvoresPlantadas[i];
    // Ajuste aqui para colher o fruto, o clique deve ser no fruto (ellipse), não na arvore inteira
    if (arvore.frutoPronto && dist(mouseX, mouseY, arvore.x + 20, arvore.y - 70) < 10) { // Raio de clique ajustado para o fruto
      money += ARVORE_FRUIT_VALUE;
      statusMensagem = `Você colheu um fruto da árvore e ganhou $${ARVORE_FRUIT_VALUE}! Total: $${money}`;
      arvore.frutoPronto = false;
      arvore.fruitTimer = 0;
      return;
    }
  }
}

function handleShopClick() {
  // Clica no botão VOLTAR
  if (dist(mouseX, mouseY, width / 2, height - 30) < 120 / 2 && dist(mouseX, mouseY, width / 2, height - 30) < 50 / 2) {
    gameState = "playing";
    statusMensagem = "De volta ao campo!";
    return;
  }

  // Ajusta o clique para o espaço do conteúdo scrollável da loja
  let clickedX_in_content = mouseX - SHOP.WINDOW_X;
  let clickedY_in_content = mouseY - SHOP.WINDOW_Y - SHOP.SCROLL_Y;

  // Verifica cliques nos botões de compra
  let itemYOffset = 40; // Espaço do título "Itens Especiais"
  for (let item of lojaItens) {
    if (checkBuyButtonClick(clickedX_in_content, clickedY_in_content, itemYOffset)) {
      processItemPurchase(item);
      return;
    }
    itemYOffset += 80;
  }

  let seedYOffset = itemYOffset + 40; // Espaço do título "Comprar Sementes"
  for (let semente of tiposSemente.filter(s => s.precoCompra > 0)) {
    if (checkBuyButtonClick(clickedX_in_content, clickedY_in_content, seedYOffset)) {
      processSeedPurchase(semente);
      return;
    }
    seedYOffset += 80;
  }
}

function checkBuyButtonClick(clickedX, clickedY, itemCurrentY) {
  const BUTTON_WIDTH = 70;
  const BUTTON_HEIGHT = 30;
  const BUTTON_X_RELATIVE = 10 + (SHOP.WINDOW_WIDTH - 40) - 80;
  const BUTTON_Y_RELATIVE = itemCurrentY + 15;

  // Verifica se o clique está dentro da área do botão
  return clickedX >= BUTTON_X_RELATIVE && clickedX <= BUTTON_X_RELATIVE + BUTTON_WIDTH &&
    clickedY >= BUTTON_Y_RELATIVE && clickedY <= BUTTON_Y_RELATIVE + BUTTON_HEIGHT &&
    // E se o clique está dentro da área visível da janela da loja
    mouseX > SHOP.WINDOW_X && mouseX < SHOP.WINDOW_X + SHOP.WINDOW_WIDTH &&
    mouseY > SHOP.WINDOW_Y && mouseY < SHOP.WINDOW_Y + SHOP.WINDOW_HEIGHT;
}

function processItemPurchase(item) {
  let isDisabled = (item.id === "regador" && temRegador) || money < item.preco;
  if (!isDisabled) {
    money -= item.preco;
    statusMensagem = `Você comprou ${item.nome}!`;
    if (item.id === "adubo") {
      aduboAtivo = true;
      aduboTempoRestante = 300;
    } else if (item.id === "arvore") {
      // Posiciona a árvore em uma área verde válida, longe da loja e da estrada
      let newTreeX = random(width * 0.1, width * 0.6); // Limita X
      let newTreeY = random(height * 0.5 + 50, height - 100); // Limita Y na área verde da frente
      arvoresPlantadas.push({ x: newTreeX, y: newTreeY, frutoPronto: false, fruitTimer: 0 });
      statusMensagem = "Muda de árvore plantada no campo! Ela dará frutos valiosos...";
    } else if (item.id === "regador") {
      temRegador = true;
      statusMensagem = "Regador automático adquirido! Plantas crescerão mais rápido.";
    }
  } else if (item.id === "regador" && temRegador) {
    statusMensagem = `Você já possui o ${item.nome}.`;
  } else {
    statusMensagem = "Dinheiro insuficiente para comprar " + item.nome + ".";
  }
}

function processSeedPurchase(semente) {
  if (!semente.desbloqueado && money >= semente.precoCompra) {
    money -= semente.precoCompra;
    semente.desbloqueado = true;
    statusMensagem = `Você comprou sementes de ${semente.nome}! Elas estão disponíveis no seletor.`;
  } else if (semente.desbloqueado) {
    statusMensagem = `Você já possui sementes de ${semente.nome}.`;
  } else {
    statusMensagem = "Dinheiro insuficiente para comprar " + semente.nome + ".";
  }
}

function mouseDragged() {
  if (gameState === "shop") {
    if (mouseX > SHOP.WINDOW_X && mouseX < SHOP.WINDOW_X + SHOP.WINDOW_WIDTH &&
      mouseY > SHOP.WINDOW_Y && mouseY < SHOP.WINDOW_Y + SHOP.WINDOW_HEIGHT) {

      SHOP.SCROLL_Y += (mouseY - pmouseY);
      let minScroll = -(SHOP.CONTENT_HEIGHT - SHOP.WINDOW_HEIGHT);
      minScroll = min(minScroll, 0); // Evita scroll negativo se o conteúdo for menor que a janela
      SHOP.SCROLL_Y = constrain(SHOP.SCROLL_Y, minScroll, 0);
    }
  }
}

function mouseWheel(event) {
  if (gameState === "shop") {
    if (mouseX > SHOP.WINDOW_X && mouseX < SHOP.WINDOW_X + SHOP.WINDOW_WIDTH &&
      mouseY > SHOP.WINDOW_Y && mouseY < SHOP.WINDOW_Y + SHOP.WINDOW_HEIGHT) {

      SHOP.SCROLL_Y += -event.delta;
      let minScroll = -(SHOP.CONTENT_HEIGHT - SHOP.WINDOW_HEIGHT);
      minScroll = min(minScroll, 0); // Evita scroll negativo se o conteúdo for menor que a janela
      SHOP.SCROLL_Y = constrain(SHOP.SCROLL_Y, minScroll, 0);
      return false;
    }
  }
}